class CategoryModel{
  String image;
  String title;

  CategoryModel(this.image, this.title);
}
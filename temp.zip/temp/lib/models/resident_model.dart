class ResidentModel{
  String name;
  String direction;
  String telNum;
  String image;

  ResidentModel({this.name, this.direction, this.telNum, this.image});
}
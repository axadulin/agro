class AlbumModel{
  String title;
  String image;
  String info;

  AlbumModel(this.title, this.image, this.info);
}